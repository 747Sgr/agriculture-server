create view PERSON_V as
SELECT "name" FROM "person"
/

